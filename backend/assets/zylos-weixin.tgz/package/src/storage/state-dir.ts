import os from "node:os";
import path from "node:path";

/** Resolve the Zylos weixin state directory. */
export function resolveStateDir(): string {
  return (
    process.env.ZYLOS_STATE_DIR?.trim() ||
    path.join(os.homedir(), "zylos/components/weixin")
  );
}
