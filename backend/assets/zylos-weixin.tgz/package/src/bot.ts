/**
 * zylos-weixin — Weixin channel for Zylos Bot
 * QR-code login + long-poll getUpdates + C4 comm-bridge dispatch.
 *
 * Based on openclaw-weixin, adapted for Zylos C4 architecture.
 */

import { execFile } from "node:child_process";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";

import { getUpdates } from "./api/api.js";
import type { WeixinMessage, MessageItem } from "./api/types.js";
import { MessageItemType } from "./api/types.js";
import {
  listIndexedAccountIds,
  registerAccountId,
  normalizeAccountId,
  saveAccount,
  resolveAccount,
  clearStaleAccountsForUserId,
  DEFAULT_BASE_URL,
} from "./auth/accounts.js";
import type { ResolvedAccount } from "./auth/accounts.js";
import {
  DEFAULT_ILINK_BOT_TYPE,
  startWeixinLoginWithQr,
  waitForWeixinLogin,
} from "./auth/login-qr.js";
import { downloadMediaFromItem } from "./media/media-download.js";
import type { MediaDownloadResult } from "./media/media-download.js";
import { getSyncBufFilePath, loadGetUpdatesBuf, saveGetUpdatesBuf } from "./storage/sync-buf.js";
import { logger } from "./util/logger.js";

// ─── Constants ──────────────────────────────────────────────

const HOME = process.env.HOME || os.homedir();
const C4_RECEIVE = path.join(HOME, "zylos/.claude/skills/comm-bridge/scripts/c4-receive.js");
const C4_CHANNEL = "weixin";

const DEFAULT_LONG_POLL_TIMEOUT_MS = 35_000;
const MAX_CONSECUTIVE_FAILURES = 3;
const BACKOFF_DELAY_MS = 30_000;
const RETRY_DELAY_MS = 2_000;
const SESSION_EXPIRED_ERRCODE = -14;

const MAX_CONCURRENT_C4 = 10;
let _activeC4Calls = 0;

// ─── C4 Bridge ──────────────────────────────────────────────

function c4Endpoint(accountId: string, target: string): string {
  const allIds = listIndexedAccountIds();
  if (allIds.length <= 1) return target;
  return `account:${accountId}|${target}`;
}

function sendToC4(channel: string, endpoint: string, content: string): void {
  if (!content) return;
  if (_activeC4Calls >= MAX_CONCURRENT_C4) {
    console.warn(`[zylos-weixin] C4 concurrency cap reached (${MAX_CONCURRENT_C4}), dropping message`);
    return;
  }
  _activeC4Calls++;
  const c4Args = [C4_RECEIVE, "--channel", channel, "--endpoint", endpoint, "--json", "--content", content];

  execFile("node", c4Args, { encoding: "utf8" }, (error, stdout) => {
    _activeC4Calls--;
    if (!error) {
      console.log(`[zylos-weixin] -> C4: ${content.substring(0, 80)}...`);
      if (stdout?.trim()) console.log(`[zylos-weixin] C4 stdout: ${stdout.trim()}`);
    } else {
      console.error(`[zylos-weixin] C4 error: ${error.message}`);
      // Retry once
      _activeC4Calls++;
      execFile("node", c4Args, { encoding: "utf8" }, (retryErr) => {
        _activeC4Calls--;
        if (retryErr) console.error(`[zylos-weixin] C4 retry failed: ${retryErr.message}`);
        else console.log(`[zylos-weixin] -> C4 (retry): ${content.substring(0, 80)}...`);
      });
    }
  });
}

// ─── Message formatting ─────────────────────────────────────

function escapeXml(str: string): string {
  return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
}

function extractTextBody(itemList?: MessageItem[]): string {
  if (!itemList?.length) return "";
  for (const item of itemList) {
    if (item.type === MessageItemType.TEXT && item.text_item?.text != null) {
      return String(item.text_item.text);
    }
    if (item.type === MessageItemType.VOICE && item.voice_item?.text) {
      return item.voice_item.text;
    }
  }
  return "";
}

function formatInboundMessage(
  msg: WeixinMessage,
  accountId: string,
  mediaResult: MediaDownloadResult,
): string {
  const sender = msg.from_user_id ?? "unknown";
  const text = extractTextBody(msg.item_list);

  const parts: string[] = [];
  parts.push(`[Weixin DM] ${escapeXml(sender)} said: ${escapeXml(text)}`);

  // Add media references
  if (mediaResult.decryptedPicPath) {
    parts.push(`\n[image: ${mediaResult.decryptedPicPath}]`);
  }
  if (mediaResult.decryptedVideoPath) {
    parts.push(`\n[video: ${mediaResult.decryptedVideoPath}]`);
  }
  if (mediaResult.decryptedFilePath) {
    parts.push(`\n[file: ${mediaResult.decryptedFilePath}]`);
  }
  if (mediaResult.decryptedVoicePath) {
    parts.push(`\n[voice: ${mediaResult.decryptedVoicePath}]`);
  }

  return parts.join("");
}

// ─── Context token store ────────────────────────────────────

const contextTokenStore = new Map<string, string>();

function contextTokenKey(accountId: string, userId: string): string {
  return `${accountId}:${userId}`;
}

function setContextToken(accountId: string, userId: string, token: string): void {
  contextTokenStore.set(contextTokenKey(accountId, userId), token);
  // Persist to disk
  persistContextTokens(accountId);
}

export function getContextToken(accountId: string, userId: string): string | undefined {
  return contextTokenStore.get(contextTokenKey(accountId, userId));
}

function persistContextTokens(accountId: string): void {
  const prefix = `${accountId}:`;
  const tokens: Record<string, string> = {};
  for (const [k, v] of contextTokenStore) {
    if (k.startsWith(prefix)) tokens[k.slice(prefix.length)] = v;
  }
  try {
    const dir = path.join(HOME, "zylos/components/weixin/accounts");
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(path.join(dir, `${accountId}.context-tokens.json`), JSON.stringify(tokens, null, 0), "utf-8");
  } catch (err) {
    logger.warn(`persistContextTokens: failed: ${String(err)}`);
  }
}

function restoreContextTokens(accountId: string): void {
  try {
    const filePath = path.join(HOME, "zylos/components/weixin/accounts", `${accountId}.context-tokens.json`);
    if (!fs.existsSync(filePath)) return;
    const raw = fs.readFileSync(filePath, "utf-8");
    const tokens = JSON.parse(raw) as Record<string, string>;
    let count = 0;
    for (const [userId, token] of Object.entries(tokens)) {
      if (typeof token === "string" && token) {
        contextTokenStore.set(contextTokenKey(accountId, userId), token);
        count++;
      }
    }
    logger.info(`restoreContextTokens: restored ${count} tokens for account=${accountId}`);
  } catch (err) {
    logger.warn(`restoreContextTokens: failed: ${String(err)}`);
  }
}

// ─── Monitor loop ───────────────────────────────────────────

async function monitorAccount(
  account: ResolvedAccount,
  abortSignal: AbortSignal,
): Promise<void> {
  const { accountId, baseUrl, cdnBaseUrl, token } = account;
  const aLog = logger.withAccount(accountId);

  aLog.info(`Monitor started: baseUrl=${baseUrl}`);
  console.log(`[zylos-weixin] Monitor started for account=${accountId}`);

  restoreContextTokens(accountId);

  const syncFilePath = getSyncBufFilePath(accountId);
  const previousBuf = loadGetUpdatesBuf(syncFilePath);
  let getUpdatesBuf = previousBuf ?? "";

  if (previousBuf) {
    console.log(`[zylos-weixin] Resuming from previous sync buf (${getUpdatesBuf.length} bytes)`);
  }

  let nextTimeoutMs = DEFAULT_LONG_POLL_TIMEOUT_MS;
  let consecutiveFailures = 0;

  while (!abortSignal.aborted) {
    try {
      const resp = await getUpdates({
        baseUrl,
        token,
        get_updates_buf: getUpdatesBuf,
        timeoutMs: nextTimeoutMs,
      });

      if (resp.longpolling_timeout_ms != null && resp.longpolling_timeout_ms > 0) {
        nextTimeoutMs = resp.longpolling_timeout_ms;
      }

      const isApiError =
        (resp.ret !== undefined && resp.ret !== 0) ||
        (resp.errcode !== undefined && resp.errcode !== 0);

      if (isApiError) {
        const isSessionExpired =
          resp.errcode === SESSION_EXPIRED_ERRCODE || resp.ret === SESSION_EXPIRED_ERRCODE;

        if (isSessionExpired) {
          aLog.error(`Session expired (errcode ${SESSION_EXPIRED_ERRCODE}), pausing 5 min`);
          console.error(`[zylos-weixin] Session expired for ${accountId}, pausing 5 min`);
          consecutiveFailures = 0;
          await sleep(5 * 60_000, abortSignal);
          continue;
        }

        consecutiveFailures++;
        aLog.error(`getUpdates failed: ret=${resp.ret} errcode=${resp.errcode} errmsg=${resp.errmsg}`);
        if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
          aLog.error(`${MAX_CONSECUTIVE_FAILURES} consecutive failures, backing off 30s`);
          consecutiveFailures = 0;
          await sleep(BACKOFF_DELAY_MS, abortSignal);
        } else {
          await sleep(RETRY_DELAY_MS, abortSignal);
        }
        continue;
      }

      consecutiveFailures = 0;

      if (resp.get_updates_buf != null && resp.get_updates_buf !== "") {
        saveGetUpdatesBuf(syncFilePath, resp.get_updates_buf);
        getUpdatesBuf = resp.get_updates_buf;
      }

      const list = resp.msgs ?? [];
      for (const full of list) {
        const fromUserId = full.from_user_id ?? "";
        aLog.info(`inbound message: from=${fromUserId} types=${full.item_list?.map((i) => i.type).join(",") ?? "none"}`);

        // Download media
        const hasDownloadableMedia = (m?: { encrypt_query_param?: string; full_url?: string }) =>
          m?.encrypt_query_param || m?.full_url;
        const mediaItem =
          full.item_list?.find((i) => i.type === MessageItemType.IMAGE && hasDownloadableMedia(i.image_item?.media)) ??
          full.item_list?.find((i) => i.type === MessageItemType.VIDEO && hasDownloadableMedia(i.video_item?.media)) ??
          full.item_list?.find((i) => i.type === MessageItemType.FILE && hasDownloadableMedia(i.file_item?.media)) ??
          full.item_list?.find((i) => i.type === MessageItemType.VOICE && hasDownloadableMedia(i.voice_item?.media) && !i.voice_item?.text);

        let mediaResult: MediaDownloadResult = {};
        if (mediaItem) {
          mediaResult = await downloadMediaFromItem(mediaItem, {
            cdnBaseUrl,
            log: (m) => aLog.info(m),
            errLog: (m) => aLog.error(m),
            label: "inbound",
          });
        }

        // Store context token
        if (full.context_token) {
          setContextToken(accountId, fromUserId, full.context_token);
        }

        // Format and dispatch to C4
        const formatted = formatInboundMessage(full, accountId, mediaResult);
        sendToC4(C4_CHANNEL, c4Endpoint(accountId, fromUserId), formatted);
      }
    } catch (err) {
      if (abortSignal.aborted) {
        aLog.info("Monitor stopped (aborted)");
        return;
      }
      consecutiveFailures++;
      aLog.error(`getUpdates error: ${String(err)}`);
      if (consecutiveFailures >= MAX_CONSECUTIVE_FAILURES) {
        consecutiveFailures = 0;
        await sleep(BACKOFF_DELAY_MS, abortSignal);
      } else {
        await sleep(RETRY_DELAY_MS, abortSignal);
      }
    }
  }
  aLog.info("Monitor ended");
}

function sleep(ms: number, signal?: AbortSignal): Promise<void> {
  return new Promise((resolve, reject) => {
    const t = setTimeout(resolve, ms);
    signal?.addEventListener("abort", () => { clearTimeout(t); reject(new Error("aborted")); }, { once: true });
  });
}

// ─── Login flow ─────────────────────────────────────────────

async function loginAccount(accountId?: string): Promise<ResolvedAccount | null> {
  console.log("\n正在启动微信扫码登录...\n");

  const startResult = await startWeixinLoginWithQr({
    accountId,
    apiBaseUrl: DEFAULT_BASE_URL,
    botType: DEFAULT_ILINK_BOT_TYPE,
    verbose: true,
  });

  if (!startResult.qrcodeUrl) {
    console.error(`登录失败: ${startResult.message}`);
    return null;
  }

  console.log("\n使用微信扫描以下二维码，以完成连接：\n");
  try {
    const qrcodeterminal = await import("qrcode-terminal");
    await new Promise<void>((resolve) => {
      qrcodeterminal.default.generate(startResult.qrcodeUrl!, { small: true }, (qr: string) => {
        console.log(qr);
        console.log("如果二维码未能成功展示，请用浏览器打开以下链接扫码：");
        console.log(startResult.qrcodeUrl!);
        resolve();
      });
    });
  } catch {
    console.log("二维码未加载成功，请用浏览器打开以下链接扫码：");
    console.log(startResult.qrcodeUrl!);
  }

  console.log("\n等待连接结果...\n");
  const waitResult = await waitForWeixinLogin({
    sessionKey: startResult.sessionKey,
    apiBaseUrl: DEFAULT_BASE_URL,
    timeoutMs: 480_000,
    verbose: true,
  });

  if (waitResult.connected && waitResult.botToken && waitResult.accountId) {
    const normalizedId = normalizeAccountId(waitResult.accountId);
    saveAccount(normalizedId, {
      token: waitResult.botToken,
      baseUrl: waitResult.baseUrl,
      userId: waitResult.userId,
    });
    registerAccountId(normalizedId);
    if (waitResult.userId) {
      clearStaleAccountsForUserId(normalizedId, waitResult.userId);
    }
    console.log(`\n✅ 与微信连接成功！ accountId=${normalizedId}`);
    return resolveAccount(normalizedId);
  } else {
    console.error(`登录失败: ${waitResult.message}`);
    return null;
  }
}

// ─── Main ───────────────────────────────────────────────────

async function main(): Promise<void> {
  console.log("[zylos-weixin] Starting...");

  // Check if any accounts are registered
  let accountIds = listIndexedAccountIds();

  if (accountIds.length === 0) {
    console.log("[zylos-weixin] No accounts found. Starting login flow...");
    const account = await loginAccount();
    if (!account) {
      console.error("[zylos-weixin] Login failed, exiting.");
      process.exit(1);
    }
    accountIds = listIndexedAccountIds();
  }

  // Start monitors for all registered accounts
  const controller = new AbortController();

  const shutdownHandler = () => {
    console.log("\n[zylos-weixin] Shutting down...");
    controller.abort();
    setTimeout(() => process.exit(0), 2000);
  };
  process.on("SIGINT", shutdownHandler);
  process.on("SIGTERM", shutdownHandler);

  console.log(`[zylos-weixin] Starting monitors for ${accountIds.length} account(s): ${accountIds.join(", ")}`);

  const monitors = accountIds.map((id) => {
    const account = resolveAccount(id);
    if (!account.configured) {
      console.warn(`[zylos-weixin] Account ${id} not configured (no token), skipping`);
      return Promise.resolve();
    }
    return monitorAccount(account, controller.signal).catch((err) => {
      console.error(`[zylos-weixin] Monitor for ${id} crashed: ${String(err)}`);
    });
  });

  await Promise.allSettled(monitors);
  console.log("[zylos-weixin] All monitors stopped.");
}

main().catch((err) => {
  console.error(`[zylos-weixin] Fatal error: ${String(err)}`);
  process.exit(1);
});
